package ThePackage;

public class calculateCommission 
{
	double commissionRate;
	double purchasePrice;
	
	public calculateCommission ()
	{
	}
	
	public double calCommission (double commissionRate, double purchasePrice)//Method for calculating commissions.
    {
        commissionRate = commissionRate / 100;
        double commission = purchasePrice * commissionRate;
        return commission;
    }
}

package ThePackage;

import java.util.*;

public class home
{

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in); //Why is my input yellow?
		
		System.out.println("");
		System.out.println("Hello!  What option would you like to check? ");
		System.out.println("Press 1 for calculating monthly payments. ");
		System.out.println("Press 2 for calculating closing cost. ");
		System.out.println("Press 3 for calculating commission rate. ");
		System.out.print("Press any integer to exit the program. ");
		int choice = input.nextInt();
		
		do
		{
			while(choice == 1)
			{
				//Calculating monthly payments.
				System.out.print("How much do you want to borrow? "); //Asks user how much they want to borrow.
				double ab = input.nextDouble();
		
				System.out.print("What's the interest on the loan? "); //Asks user for interest rate.
				double lir = input.nextDouble();
		
				System.out.print("How many months will it take to pay off the loan? "); //Asks user how many months to pay loan.
				double lim = input.nextDouble();
		
				CalculatingMonthlyPayments cmp = new CalculatingMonthlyPayments(); //Creates a new instance of calculating monthly payments.
				System.out.println("Monthly payments are " + cmp.calMonthlyPayment(ab, lir, lim) + "."); //amountBorrowed/ interestRate/ loanInMonths
				
				System.out.println("");
				System.out.println("Hello!  What option would you like to check? ");
				System.out.println("Press 1 for calculating monthly payments. ");
				System.out.println("Press 2 for calculating closing cost. ");
				System.out.println("Press 3 for calculating commission rate. ");
				System.out.print("Press any integer to exit the program. ");
				choice = input.nextInt();
			}
		//******************************************************************************************************************************
			while(choice == 2)
			{
				//Calculating closing cost.
				System.out.print("What's the purchase price of the loan? "); //Asks user for purchase price.
				double pp = input.nextDouble();
		
				System.out.print("What's the down payment for the home? "); //Asks user for down payment.
				double dp = input.nextDouble();
		
				System.out.print("What's the rate? "); //Asks user for the rate.
				double tr = input.nextDouble();
		
				CalculateClosingCost ccc = new CalculateClosingCost(); //Creates a new instance of closing cost.
				System.out.println("Closing cost are " + ccc.calClosingCost(pp, dp, tr) + "."); //Purchase price/ down payment/ the rate.
				
				System.out.println("");
				System.out.println("Hello!  What option would you like to check? ");
				System.out.println("Press 1 for calculating monthly payments. ");
				System.out.println("Press 2 for calculating closing cost. ");
				System.out.println("Press 3 for calculating commission rate. ");
				System.out.print("Press any integer to exit the program. ");
				choice = input.nextInt();
			}
		//*******************************************************************************************************************************
			while(choice == 3)
			{
				//Calculating commission rates.
				System.out.print("What's the commission rate? "); //Asks for commission rate.
				double cr = input.nextDouble ();
		
				System.out.print("What's the purchase price? "); //Asks user for the purchase price.
				double ppcc = input.nextDouble ();
		
				calculateCommission cc = new calculateCommission();
				System.out.println("The rate is " + cc.calCommission(cr, ppcc) + ".");
				
				System.out.println("");
				System.out.println("Hello!  What option would you like to check? ");
				System.out.println("Press 1 for calculating monthly payments. ");
				System.out.println("Press 2 for calculating closing cost. ");
				System.out.println("Press 3 for calculating commission rate. ");
				System.out.print("Press any integer to exit the program. ");
				choice = input.nextInt();
			}
		}while(choice <= 0 && choice > 4);
	}
}

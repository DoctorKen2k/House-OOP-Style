package ThePackage;

public class CalculateClosingCost 
{
	double myPurchasePrice;
	double myDownPayment;
	double myRate;
	
	public CalculateClosingCost ()
	{
	}
	
	public double calClosingCost (double myPurchasePrice, double myDownPayment, double myRate)//Method for calculating closing cost.
    {
        myRate = myRate / 100;
        double closingCost = (myPurchasePrice - myDownPayment) * myRate;
        return closingCost;
    }
}

package ThePackage;

public class CalculatingMonthlyPayments 
{
	public static double userAmountBorrowed; //Variables for calculated monthly payments.
	double userInterestRate;
	double userLoanInMonths;
	
	public CalculatingMonthlyPayments ()
	{
		
	}
	
	public double calMonthlyPayment (double userAmountBorrowed, double userInterestRate, double userLoanInMonths)
	{
		userInterestRate = ((userInterestRate/100)/12);
	    double monthlyPayment = ((userAmountBorrowed*userInterestRate)/(1-(Math.pow(1/(1+userInterestRate), userLoanInMonths))));
	    return monthlyPayment;
	}
}